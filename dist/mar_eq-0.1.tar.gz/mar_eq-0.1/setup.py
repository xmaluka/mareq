#Setup file which will house all settings
from setuptools import setup

setup(name='mar_eq',
        version='0.1',
        description='Random equation fro my personal use',
        url='https://github.com/xmaluka/mareq.git',
        author='Marcio Maluka',
        author_email='marciomaluka@ymail.com',
        license='MIT',
        #packages=['numpy'],
        zip_safe=False,
        )
