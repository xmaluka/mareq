#Setup file which will house all settings
from setuptools import setup

setup(name='mar_eq',
        version='0.1'
        #description='Random equation fro my personal use'
        #url='ww.github.com'
        #author='Marcio Maluka'
        #author_email='marciomaluka@ymail.com'
        #license='MIT'
        #packages=['pandas','numpy']
        #zip_safe=False
        )
